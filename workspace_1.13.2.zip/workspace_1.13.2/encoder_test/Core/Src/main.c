/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include <main.h>
#include<stdlib.h>


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
//AMR specs
const float dia = 0.15;
//initial velocity for the motor
float v_i = 10;

//values for the target velocities
float v_tar_1 = 35;
float v_tar_2 = 20;
float v_tar_3 = 20;
float v_tar_4 = 20;


//values for the dutycycles
uint32_t dutyCycle =0;
uint32_t dutyCycle2 =0;
uint32_t dutyCycle3 =0;
uint32_t dutyCycle4 =0;

//values for the current velocities

volatile float curr_vel_1 =0;
volatile float curr_vel_2 =0;
volatile float curr_vel_4 =0;
volatile float curr_vel_3 =0;
//function declaration
void HandleEncoder3(uint16_t GPIO_Pin) ;
void HandleEncoder2(uint16_t GPIO_Pin) ;
void HandleEncoder1(uint16_t GPIO_Pin) ;
void HandleEncoder4(uint16_t GPIO_PIN) ;

//values for the PID constants

const float kp=1;
const float ki=0;
const float kd =0;

float errPrev = 0;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
volatile uint32_t encodercounts_4 =0;
volatile uint32_t encodercounts_3 =0;
volatile uint32_t encodercounts_2 =0;
volatile uint32_t encodercounts_1 =0;

//velocity variable
volatile float vel_3 =0;
volatile float vel_1 =0;
volatile float vel_2 =0;
volatile float vel_4 =0;

//timer variables
float starttime =0;


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define COUNTERCLOCKWISE     GPIO_PIN_SET
#define CLOCKWISE  GPIO_PIN_RESET


#define maxDutyCycle 4799
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim14;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM14_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */
float pid_controller(float vel ,float v_tar ,float starttime);
/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void controlMotor_3(uint16_t *dutyCycle, GPIO_PinState direction) {
    float u_control = pid_controller(curr_vel_3, v_tar_3,starttime);
    // Update the duty cycle based on the control output
    if (direction == GPIO_PIN_RESET) {
                *dutyCycle += u_control;
    } else {
        *dutyCycle += u_control;
    }

    // Ensure the duty cycle is within valid limits (0 to maxDutyCycle)
    if (*dutyCycle < 0) {
        *dutyCycle = abs(*dutyCycle);
        direction = COUNTERCLOCKWISE;

    } else if (*dutyCycle > maxDutyCycle) {
        *dutyCycle = maxDutyCycle;
    }

    // Set the motor duty cycle with the updated dutycycle
    HAL_GPIO_WritePin(M3D_GPIO_Port, M3D_Pin, direction);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, *dutyCycle);
}

void controlMotor_4(uint16_t dutyCycle , GPIO_PinState direction)
{
	 HAL_GPIO_WritePin(M4D_GPIO_Port ,M4D_Pin, direction);
	 __HAL_TIM_SET_COMPARE(&htim14, TIM_CHANNEL_1, dutyCycle);
}

void controlMotor_2(uint16_t dutycycle , GPIO_PinState direction)
{
	HAL_GPIO_WritePin(M2D_GPIO_Port , M2D_Pin , direction);
	__HAL_TIM_SET_COMPARE(&htim3 ,TIM_CHANNEL_1 ,dutycycle);
}

void controlMotor_1(uint16_t dutycycle , GPIO_PinState direction)
{
	HAL_GPIO_WritePin(M1D_GPIO_Port , M1D_Pin , direction);
	__HAL_TIM_SET_COMPARE(&htim1 ,TIM_CHANNEL_3 ,dutycycle);
}

//PID function
float pid_controller(float vel ,float v_tar ,float starttime)
{

	float curr_time = HAL_GetTick();
	float elapsed_time = curr_time - starttime;
	//propotional error control
	float p_error = v_tar - vel;
	//differential error control
	float diff_error = ((p_error - errPrev)* 1000) / elapsed_time ;
	//integral error control
	float integ_error = p_error * (elapsed_time/1000) ;
	//total control aka u_control
	float u_control = kp* p_error + ki * integ_error + kd * diff_error;
	errPrev = p_error;

	return u_control;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

  HAL_NVIC_SetPriority(EXTI0_1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_1_IRQn);
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  MX_TIM14_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */
  starttime = HAL_GetTick();
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

	  uint16_t initialDutyCycle = 500;
	  controlMotor_3(&initialDutyCycle, GPIO_PIN_SET);

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 4799;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 127;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_ENABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */
  HAL_TIM_Base_Start(&htim1);
   HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_3);
  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_SlaveConfigTypeDef sSlaveConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 4799;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_DISABLE;
  sSlaveConfig.InputTrigger = TIM_TS_ITR0;
  if (HAL_TIM_SlaveConfigSynchro(&htim3, &sSlaveConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.Pulse = 127;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */
  HAL_TIM_Base_Start(&htim3);
  HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM14 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM14_Init(void)
{

  /* USER CODE BEGIN TIM14_Init 0 */

  /* USER CODE END TIM14_Init 0 */

  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM14_Init 1 */

  /* USER CODE END TIM14_Init 1 */
  htim14.Instance = TIM14;
  htim14.Init.Prescaler = 0;
  htim14.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim14.Init.Period = 4799;
  htim14.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim14.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim14) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim14) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 127;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim14, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM14_Init 2 */
  HAL_TIM_Base_Start(&htim14);
  HAL_TIM_PWM_Start(&htim14,TIM_CHANNEL_1);
  /* USER CODE END TIM14_Init 2 */
  HAL_TIM_MspPostInit(&htim14);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 38400;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, M4D_Pin|M3D_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, M2D_Pin|M1D_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : E1A_Pin E1B_Pin E3B_Pin */
  GPIO_InitStruct.Pin = E1A_Pin|E1B_Pin|E3B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : M4D_Pin M3D_Pin */
  GPIO_InitStruct.Pin = M4D_Pin|M3D_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : E4B_Pin E2A_Pin E2B_Pin */
  GPIO_InitStruct.Pin = E4B_Pin|E2A_Pin|E2B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : E3A_Pin E4A_Pin */
  GPIO_InitStruct.Pin = E3A_Pin|E4A_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : M2D_Pin M1D_Pin */
  GPIO_InitStruct.Pin = M2D_Pin|M1D_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB8 */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF2_TIM16;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF2_TIM17;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /**/
  HAL_I2CEx_EnableFastModePlus(SYSCFG_CFGR1_I2C_FMP_PB6);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_1_IRQn);

  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/*encoder logic */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)//callback function of the interrupt handler
{
	   if (GPIO_Pin == E3A_Pin || GPIO_Pin == E3B_Pin) {
	        HandleEncoder3(GPIO_Pin);
	    }
	   else if (GPIO_Pin == E1A_Pin || GPIO_Pin == E1B_Pin)
	    {
	        HandleEncoder1(GPIO_Pin);
	    }
	    else if(GPIO_Pin == E2A_Pin || GPIO_Pin == E2B_Pin  )
	    {
	    	HandleEncoder2(GPIO_Pin);
	    }
	    else if(GPIO_Pin == E4A_Pin || GPIO_Pin == E4B_Pin  )
		{
	    	HandleEncoder4(GPIO_Pin);

		}
}


void HandleEncoder3(uint16_t GPIO_Pin) {

	float time_3 = HAL_GetTick();
    static uint8_t prevE3AState = 0;
    static uint8_t prevE3BState = 0;

    uint8_t currentE3AState = HAL_GPIO_ReadPin(E3A_GPIO_Port, E3A_Pin);
    uint8_t currentE3BState = HAL_GPIO_ReadPin(E3B_GPIO_Port, E3B_Pin);

    //this logic uses xor instead of the nested loop this is intuitive with the truth table
    uint8_t xorE3A = currentE3AState ^ prevE3BState;
    uint8_t xorE3B = currentE3BState ^ prevE3AState;

    if (xorE3A) {
        encodercounts_3++;
    }
    if (xorE3B && (encodercounts_3 > 0)) {
        encodercounts_3--;
    }
    float elapsed_time_3 = (time_3 - starttime)/1.0e3;
    vel_3 = (encodercounts_3 / 537.6)/elapsed_time_3;
    curr_vel_3 = vel_3 * dia;

    // Update the previous states for the next interrupt
    prevE3AState = currentE3AState;
    prevE3BState = currentE3BState;
}

void HandleEncoder1(uint16_t GPIO_Pin) {
    static uint8_t prevE1AState = 0;
    static uint8_t prevE1BState = 0;

    uint8_t currentE1AState = HAL_GPIO_ReadPin(E1A_GPIO_Port, E1A_Pin);
    uint8_t currentE1BState = HAL_GPIO_ReadPin(E1B_GPIO_Port, E1B_Pin);

    uint8_t xorE1A = currentE1AState ^ prevE1BState;
    uint8_t xorE1B = currentE1BState ^ prevE1AState;

    if (xorE1A) {
        encodercounts_1++;
        vel_1 = encodercounts_1 / 537.6;
    }
    if (xorE1B && (encodercounts_1 > 0)) {
        encodercounts_1--;
    }

    // Update the previous states for the next interrupt
    prevE1AState = currentE1AState;
    prevE1BState = currentE1BState;
}

void HandleEncoder2(uint16_t GPIO_Pin)
{
	    static uint8_t prevE2AState = 0;
	    static uint8_t prevE2BState = 0;

	    uint8_t currentE2AState = HAL_GPIO_ReadPin(E2A_GPIO_Port, E2A_Pin);
	    uint8_t currentE2BState = HAL_GPIO_ReadPin(E2B_GPIO_Port, E2B_Pin);

	    uint8_t xorE2A = currentE2AState ^ prevE2BState;
	    uint8_t xorE2B = currentE2BState ^ prevE2AState;

	    if (xorE2A) {
	        encodercounts_2++;
	        vel_2 = encodercounts_2 / 537.6;
	    }
	    if (xorE2B && (encodercounts_2 > 0)) {
	        encodercounts_2--;
	    }

	    // Update the previous states for the next interrupt
	    prevE2AState = currentE2AState;
	    prevE2BState = currentE2BState;
}


void HandleEncoder4(uint16_t GPIO_Pin)
{
    static uint8_t prevE4AState = 0;
    static uint8_t prevE4BState = 0;

    uint8_t currentE4AState = HAL_GPIO_ReadPin(E4A_GPIO_Port, E4A_Pin);
    uint8_t currentE4BState = HAL_GPIO_ReadPin(E4B_GPIO_Port, E4B_Pin);

    uint8_t xorE4A = currentE4AState ^ prevE4BState;
    uint8_t xorE4B = currentE4BState ^ prevE4AState;

    if (xorE4A) {
        encodercounts_4++;
        vel_4 = encodercounts_4/ 537.6;
    }
    if (xorE4B && (encodercounts_4 > 0)) {
        encodercounts_4--;
    }

    // Update the previous states for the next interrupt
    prevE4AState = currentE4AState;
    prevE4BState = currentE4BState;
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  //__disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

